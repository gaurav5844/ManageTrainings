﻿USE [Training]
GO

/****** Object: Table [dbo].[ManageTrainings] Script Date: 31/07/2019 4:54:28 PM ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO

CREATE TABLE [dbo].[ManageTrainings] (
    [Id]        INT          IDENTITY (1, 1) NOT NULL,
    [Name]      VARCHAR (50) NOT NULL,
    [StartDate] DATETIME     NULL,
    [EndDate]   DATETIME     NULL
);


