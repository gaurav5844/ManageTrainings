﻿using System.Data.Entity;
using System.Linq;
using System.Web.Http;
using System.Web.Mvc;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using Moq;
using TrainingManager;
using TrainingManager.Controllers;
using TrainingManager.Models;

namespace TrainingManager.Tests.Controllers
{
    [TestClass]
    public class ManageTrainingsControllerTest
    {
        [TestMethod]
        public void Check_For_ReturnType_Of_ExistingTrainings()
        {
            // Arrange
            var controller = new ManageTrainingsController();

            // Act
            var result = controller.GetAllTrainings() as IQueryable<ManageTraining>;

            // Assert
            Assert.IsInstanceOfType(result, typeof(DbSet<ManageTraining>));
        }
      
        [TestMethod]
        public void Create_New_Training()
        {
            // Arrange
            var controller = new ManageTrainingsController();

            // Act
            var newTraining = new ManageTraining()
            {
                Name = "Test Training 2",
                StartDate = System.DateTime.Now,
                EndDate = System.DateTime.Now.AddDays(1),
            };

            var result = controller.CreateTraining(newTraining) as System.Web.Http.Results.CreatedAtRouteNegotiatedContentResult<ManageTraining>;

            // Assert
            Assert.AreEqual(result.Content.Name, "Test Training 2");
        }
    }
}
